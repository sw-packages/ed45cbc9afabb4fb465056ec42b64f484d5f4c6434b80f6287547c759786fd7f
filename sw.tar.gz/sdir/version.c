#include "config.h"

const char *version_string = PACKAGE_STRING;
